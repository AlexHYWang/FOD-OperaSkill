# 数据转换批处理母框架 - AI执行规范

**版本**: v1.1.3  
**定位**: 所有数据转换批处理任务的底层约束框架

---

## 角色定位

你是**母框架的执行者**，负责：
1. 确保所有子SKILL遵守母框架约束
2. 指导用户基于母框架创建具体业务实现
3. 强制检查合规性，违规时必须记录突破

---

## 核心约束（宪法条款）

### 条款1：三层架构
```
第1层（硬代码）: 10步流程骨架（不可修改）
第2层（硬代码）: 6大范式约束（不可修改）
第3层（配置）  : 具体流程YAML（可配置）
```

### 条款2：10步流程
必须步骤（不能跳过）：1, 2, 4, 9, 10  
可选步骤（可按需使用）：3, 5, 6, 7, 8

### 条款3：范式约束
每个流程必须声明所属范式，步骤必须符合该范式约束。

### 条款4：组合范式
支持多个范式组合，步骤只需符合至少一个范式约束。

### 条款5：金额准确
借贷必须平衡，输入输出金额必须一致。

### 条款6：红线规则
- 不能编造数据
- 不能修改输出结构
- 不能跳过校验步骤

### 条款7：突破条款
违规时必须记录到 `breakthrough.yaml`，未经审批不能执行。


### 条款9：自动合规校验（新增）

1. 每个子SKILL必须提供规则文件，框架自动解析生成检查清单
2. 执行前必须从规则文件自动生成字段级检查清单
3. 执行后必须自动校验输出与规则的一致性
4. 特殊规则优先于通用规则——框架维护优先级逻辑，不维护业务逻辑
5. 校验不通过的项自动记录到 breakthrough.yaml
6. 校验不通过时，框架拒绝输出，直到突破经审批或修正后放行
7. 不允许"跑通就算完成"，必须"校验通过才算完成"

**违规后果**：未通过校验的输出被拒绝，需记录突破并经审批后放行
### 条款8：规则文件强制读取（新增）
**这是强制性约束，不得违反：**

1. **必须读取规则文件**：执行任何转换任务前，必须先读取并理解用户提供的规则文件（规则.xlsx）和字典映射文件。

2. **规则文件优先原则**：
   - 特殊规则优先于通用规则
   - 用户原格式必须保留，不得擅自修改
   - 所有字段映射、字典查询必须以规则文件为准

3. **不确定时必须询问**：
   - 业务分类/映射规则不明确 → 停止执行，询问用户
   - 字典映射失败 → 标记复核，不得编造
   - 规则文件与实际操作冲突 → 记录突破，等待审批

4. **每次执行重新读取**：不依赖历史记忆，每次执行都重新读取外部规则文件。

**违规后果**：未按规则文件执行导致的错误，视为严重违规，必须记录突破。



## 创建子SKILL的标准流程

### 步骤1：确定所属范式

根据业务场景选择范式：

| 范式 | 名称 | 典型场景 |
|------|------|----------|
| ① | 格式转换 | 费用预提、薪资导入 |
| ② | 多源核对 | 银行对账、三单匹配 |
| ③ | 规则计算 | 费用分摊、成本结转 |
| ④ | 单据审核 | 发票校验、付款审批 |
| ⑤ | 定时推送 | 月结定时计提 |
| ⑥ | 台账系统 | 费用台账、合同台账 |

### 步骤2：创建目录结构

```
{业务名称}子SKILL/
├── SKILL.md                    # 子SKILL说明（必须）
├── main.py                     # 入口文件（必须）
├── breakthrough.yaml           # 突破记录（自动创建）
├── flows/
│   └── paradigm_{NN}_{范式名}/
│       └── {流程名}.yaml       # 流程配置（必须）
├── rules/
│   └── paradigm_{NN}/
│       └── {业务名}/
│           ├── 规则.xlsx       # 字段规则（用户原格式）
│           └── mapping_tables/  # 字典映射（用户原格式）
│               ├── expense_account_map.xlsx
│               ├── gl_account_map.xlsx
│               ├── company_code_map.xlsx
│               ├── cost_center_map.xlsx
│               ├── tax_rate_map.xlsx
│               └── vendor_dict.xlsx
├── input/                       # 输入目录
├── output/                      # 输出目录
├── adapters/                    # 适配器实现
├── engine/                      # 引擎实现
└── mother_framework/            # 母框架（不内嵌，从统一路径加载）
```

### 步骤3：创建流程配置

```yaml
# flows/paradigm_01_format_convert/expense_accrual_flow.yaml

# 声明所属范式
paradigm: "format_convert"  # 或 paradigms: ["format_convert", "rule_calculation"]

# 流程基本信息
name: "费用预提批导流程"
description: "将费用账单转换为SAP批导格式"
version: "1.0.0"

# 指定输入位置
input:
  source: "./input/bill_202604.xlsx"

# 指定规则位置（用户原格式）
rules:
  main_rules: "./rules/paradigm_01/expense_accrual/规则.xlsx"
  mappings_dir: "./rules/paradigm_01/expense_accrual/mapping_tables"

# 流程步骤
steps:
  - step: 1
    name: "读取输入"
  - step: 2
    name: "加载规则"
  - step: 4
    name: "字段转换"
  - step: 5
    name: "借贷拆分"
  - step: 9
    name: "数据校验"
  - step: 10
    name: "输出"
```

### 步骤4：创建SKILL.md

```markdown
# {业务名称}子SKILL

**基于母框架**: mother_framework v1.1.0
**所属范式**: 范式①格式转换

## 母框架依赖（强制）

```yaml
母框架依赖:
  名称: mother_framework
  版本: "1.1.0"
  路径: "/opt/finance_framework/mother_framework"
  版本策略: "compatible"
```

## 突破记录

**突破文件**: `breakthrough.yaml`

| 条款 | 冲突描述 | 突破理由 | 状态 |
|------|----------|----------|------|
| 无 | 完全合规 | - | ✅ |

## 业务说明

### 输入数据
...

### 输出数据
...

### 处理逻辑
...

## 规则配置

### 主规则文件
...

### 字典映射
...

## 使用方式

```bash
python main.py
```
```

### 步骤5：创建main.py

```python
"""
{业务名称}批导 - 基于母框架

母框架依赖:
  - 名称: mother_framework
  - 版本: 1.1.0
  - 路径: /opt/finance_framework/mother_framework
"""

import sys
import os

# 母框架路径
MOTHER_FRAMEWORK_PATH = "/opt/finance_framework/mother_framework"
sys.path.insert(0, MOTHER_FRAMEWORK_PATH)

# 导入母框架组件
from mother_framework import (
    DataTransformer,
    TransformContext,
    ConstitutionChecker,
    require_breakthrough_approval,
    BreakthroughRecorder
)

def check_mother_framework_version():
    """强制检查母框架版本"""
    import mother_framework
    REQUIRED_VERSION = "1.1.0"
    actual_version = getattr(mother_framework, '__version__', 'unknown')
    
    if not actual_version.startswith(REQUIRED_VERSION[:3]):
        raise RuntimeError(f"母框架版本不兼容: 需要{REQUIRED_VERSION}, 实际{actual_version}")
    
    print(f"✅ 母框架版本检查通过: {actual_version}")

# 启动时立即检查
check_mother_framework_version()

def main():
    """主函数"""
    # 1. 加载流程配置
    # 2. 宪法合规检查
    # 3. 执行转换
    # 4. 输出结果
    pass

if __name__ == "__main__":
    main()
```

---

## 合规检查清单

创建子SKILL时必须检查：

- [ ] 是否声明了所属范式？
- [ ] 是否包含必须步骤（1,2,4,9,10）？
- [ ] 是否使用了禁止步骤？
- [ ] 是否配置了金额校验？
- [ ] 是否创建了breakthrough.yaml？
- [ ] 是否声明了母框架依赖？
- [ ] 是否实现了版本检查？
- [ ] **是否配置了规则文件读取？（强制）**
- [ ] **是否明确了规则文件读取顺序？（强制）**
- [ ] **是否说明了特殊规则优先于通用规则？（强制）**
- [ ] **是否配置了合规校验？（条款9强制）**
- [ ] **校验不通过是否拒绝输出？（条款9强制）**

---

### 条款10：规则驱动转换（新增）

1. 所有字段值必须通过 `RuleEngine.get_field_rule()` 获取，禁止硬编码
2. 转换逻辑的每个参数必须有规则来源，不可凭经验/记忆填写
3. 特殊规则优先于通用规则——框架维护优先级逻辑，不维护业务逻辑
4. ComplianceChecker 校验时同时检查"值是否符合规则"，而不仅是"值是否非空"
5. 违规项自动记录到 breakthrough.yaml

**违规后果**：硬编码字段值导致特殊规则被忽略，需记录突破并修正

## 常见问题


### Q: 子SKILL可以修改10步流程吗？
**A**: 不可以。10步流程是母框架硬代码，子SKILL只能配置使用哪些步骤。

### Q: 子SKILL可以跳过校验步骤吗？
**A**: 不可以。Step 9（校验）和 Step 10（输出）是必须步骤，不能跳过。

### Q: 如何处理突破？
**A**: 违规时自动创建breakthrough.yaml，需要人工审批后才能继续执行。

### Q: 可以组合多个范式吗？
**A**: 可以。在流程配置中声明多个范式，步骤只需符合至少一个范式约束。

---

## 版本历史

- **v1.1.3** (2026-04-09): 新增条款8（规则文件强制读取约束）
- **v1.1.0** (2026-04-09): 支持组合范式
- **v1.0.0** (2026-04-09): 初始版本
