"""
合规校验引擎 - 硬代码

从规则文件自动生成检查清单，校验输出一致性。
框架提供机制，子SKILL提供规则。
"""

from typing import Dict, List, Any, Tuple, Optional
from dataclasses import dataclass, field
import pandas as pd
import yaml
import os
from datetime import datetime


@dataclass
class CheckItem:
    """检查项"""
    field_name: str
    field_index: int
    is_required: bool
    rule_description: str
    rule_source: str  # general / special_required / special_optional
    data_source_hint: str = ""
    status: str = "pending"  # pending/passed/failed/warning/skipped
    message: str = ""


@dataclass
class ValidationResult:
    """校验结果"""
    passed: bool
    checklist: List[CheckItem]
    violations: List[CheckItem]
    warnings: List[CheckItem]
    summary: Dict[str, int] = field(default_factory=dict)

    def report(self) -> str:
        lines = []
        lines.append("=" * 60)
        lines.append("📋 自动合规校验报告")
        lines.append("=" * 60)
        lines.append(f"\n✅ 通过: {self.summary.get('passed', 0)}")
        lines.append(f"❌ 不通过: {self.summary.get('failed', 0)}")
        lines.append(f"⚠️ 警告: {self.summary.get('warning', 0)}")
        lines.append(f"⏭️ 跳过: {self.summary.get('skipped', 0)}")
        if self.violations:
            lines.append(f"\n{'='*60}")
            lines.append("❌ 不通过项")
            lines.append("=" * 60)
            for item in self.violations:
                lines.append(f"  [{item.field_name}] {item.message}")
                lines.append(f"    规则: {item.rule_description[:80]}")
        if self.warnings:
            lines.append(f"\n{'='*60}")
            lines.append("⚠️ 警告项")
            lines.append("=" * 60)
            for item in self.warnings:
                lines.append(f"  [{item.field_name}] {item.message}")
        lines.append(f"\n{'='*60}")
        lines.append("✅ 校验通过" if self.passed else "❌ 校验未通过，需修正或审批突破")
        lines.append("=" * 60)
        return "\n".join(lines)


class ComplianceChecker:
    """
    合规校验引擎
    框架提供机制（优先级、校验逻辑），子SKILL提供规则（规则文件）。
    """
    RULE_PRIORITY = ['special_required', 'special_optional', 'general']

    def load_checklist(self, rules_file: str,
                       template_sheet: str = '输出模板',
                       field_sheet: str = '字段清单',
                       general_sheet: str = '通用规则',
                       special_required_sheet: str = '必填字段特殊规则',
                       special_optional_sheet: str = '选填字段特殊规则',
                       bill_type: str = None) -> List[CheckItem]:
        checklist = []
        template_df = pd.read_excel(rules_file, sheet_name=template_sheet, header=0)
        template_cols = list(template_df.columns)

        field_df = pd.read_excel(rules_file, sheet_name=field_sheet)
        required_fields = set()
        for _, row in field_df.iterrows():
            if pd.notna(row.get('字段名称')):
                if '必填' in str(row.get('选填or必填', '')):
                    required_fields.add(row['字段名称'])

        general_df = pd.read_excel(rules_file, sheet_name=general_sheet)
        general_rules = {}
        for _, row in general_df.iterrows():
            if pd.notna(row.get('字段名称')) and pd.notna(row.get('通用规则')):
                general_rules[row['字段名称']] = str(row['通用规则'])

        special_required_rules = {}
        special_optional_rules = {}
        if bill_type:
            try:
                sr_df = pd.read_excel(rules_file, sheet_name=special_required_sheet)
                for _, row in sr_df.iterrows():
                    if str(row.get('费用类型', '')) == bill_type:
                        for col in sr_df.columns:
                            val = row.get(col)
                            if pd.notna(val) and str(val).strip() != '同通用规则':
                                special_required_rules[col] = str(val)
                        break
            except Exception:
                pass
            try:
                so_df = pd.read_excel(rules_file, sheet_name=special_optional_sheet)
                for _, row in so_df.iterrows():
                    if bill_type in str(row.get('费用类型', '')):
                        for col in so_df.columns:
                            val = row.get(col)
                            if pd.notna(val) and str(val).strip() != '同通用规则':
                                special_optional_rules[col] = str(val)
                        break
            except Exception:
                pass

        for idx, col_name in enumerate(template_cols):
            field_name = col_name.split('\n')[0].strip()
            is_required = field_name in required_fields
            rule_desc = ""
            rule_source = "general"
            if field_name in special_required_rules:
                rule_desc = special_required_rules[field_name]
                rule_source = "special_required"
            elif field_name in special_optional_rules:
                rule_desc = special_optional_rules[field_name]
                rule_source = "special_optional"
            elif field_name in general_rules:
                rule_desc = general_rules[field_name]
                rule_source = "general"
            data_hint = self._analyze_rule(rule_desc)
            checklist.append(CheckItem(
                field_name=field_name, field_index=idx, is_required=is_required,
                rule_description=rule_desc, rule_source=rule_source, data_source_hint=data_hint,
            ))
        return checklist

    def _analyze_rule(self, rule: str) -> str:
        if not rule:
            return "无规则"
        rule = str(rule).strip()
        if rule.startswith('固定值:') or rule in ['SA', '1', '0']:
            return "固定值"
        if rule == '当前日期':
            return "系统日期"
        if '从输入获取' in rule or '从账单' in rule:
            return "输入字段映射"
        if '查字典' in rule:
            return "字典映射"
        if '同通用规则' in rule:
            return "继承通用规则"
        if '预提' in rule or '计提' in rule:
            return "文本拼接"
        if rule in ['不填', '（空白）', '留空']:
            return "留空"
        return "自定义逻辑"

    def validate(self, output: pd.DataFrame, checklist: List[CheckItem]) -> ValidationResult:
        violations, warnings = [], []
        passed_count = skipped_count = 0
        for item in checklist:
            if item.field_index >= len(output.columns):
                item.status = "skipped"; item.message = "字段不在输出中"; skipped_count += 1; continue
            col_data = output.iloc[:, item.field_index]
            if item.data_source_hint == "留空":
                filled = ((col_data.notna()) & (col_data.astype(str) != '') & (col_data.astype(str) != 'nan')).sum()
                if filled > 0:
                    item.status = "failed"; item.message = f"规则要求留空但{filled}行有值"; violations.append(item)
                else:
                    item.status = "passed"; passed_count += 1
                continue
            null_count = (col_data.isna() | (col_data.astype(str) == '') | (col_data.astype(str) == 'nan')).sum()
            if item.is_required:
                if null_count > 0 and '不填' not in item.rule_description and '留空' not in item.rule_description:
                    item.status = "failed"; item.message = f"必填字段有{null_count}行为空"; violations.append(item)
                else:
                    item.status = "passed"; passed_count += 1
            else:
                if null_count == len(output) and item.rule_description and item.data_source_hint not in ['留空', '无规则']:
                    item.status = "warning"; item.message = f"选填字段全空，规则要求: {item.rule_description[:50]}"; warnings.append(item)
                else:
                    item.status = "passed"; passed_count += 1
        return ValidationResult(
            passed=len(violations) == 0, checklist=checklist, violations=violations, warnings=warnings,
            summary={'total': len(checklist), 'passed': passed_count, 'failed': len(violations), 'warning': len(warnings), 'skipped': skipped_count}
        )

    def record_breakthrough(self, violations: List[CheckItem], breakthrough_file: str = 'breakthrough.yaml', bill_type: str = '') -> None:
        if not violations: return
        existing = []
        if os.path.exists(breakthrough_file):
            with open(breakthrough_file, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f) or {}; existing = data.get('constitution_violations', [])
        for item in violations:
            existing.append({
                'article': '条款9', 'clause': '自动合规校验',
                'violation': f"[{item.field_name}] {item.message}",
                'rule': item.rule_description[:100], 'bill_type': bill_type,
                'justification': '', 'approved_by': '', 'approved_at': '',
                'status': 'pending', 'recorded_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            })
        with open(breakthrough_file, 'w', encoding='utf-8') as f:
            yaml.dump({'constitution_violations': existing}, f, allow_unicode=True, default_flow_style=False)
