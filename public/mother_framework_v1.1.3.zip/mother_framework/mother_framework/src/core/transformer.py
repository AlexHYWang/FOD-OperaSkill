"""
数据转换器主类 - 硬代码骨架
处理流程固定，规则数据动态
"""

import pandas as pd
import os
from typing import Dict, List, Any, Tuple, Union
from datetime import datetime

from .interfaces import (
    SourceAdapter, RuleEngine, TransformEngine, 
    Validator, OutputAdapter,
    TransformContext, TransformResult, FieldValue, ValidationError
)


class DataTransformer:
    """
    数据转换器主类 - 硬代码骨架
    
    核心要求：一分钱都不能差
    处理流程固定，规则数据动态加载
    """
    
    def __init__(self, 
                 source_adapter: SourceAdapter,
                 rule_engine: RuleEngine,
                 transform_engine: TransformEngine,
                 validator: Validator,
                 output_adapter: OutputAdapter):
        """
        初始化 - 硬代码：依赖注入固定
        """
        self.source_adapter = source_adapter
        self.rule_engine = rule_engine
        self.transform_engine = transform_engine
        self.validator = validator
        self.output_adapter = output_adapter
        
        # 复核标记收集器
        self._review_marks: Dict[int, List[str]] = {}
    
    def transform(self, input_source: Any, 
                  context: TransformContext) -> TransformResult:
        """
        主转换流程 - 硬代码：步骤固定不可变
        
        流程：
        1. 读取输入
        2. 加载规则（热更新）
        3. 预处理
        4. 规则应用转换
        5. 行拆分
        6. 行合并
        7. 分配编号
        8. 后处理
        9. 校验（一分钱都不能差）
        10. 输出
        """
        self._review_marks = {}
        errors = []
        
        try:
            # Step 1: 读取输入（硬代码流程）
            raw_data = self._read_input(input_source, context)
            
            # Step 2: 加载规则（硬代码流程，数据动态）
            rules = self._load_rules(context)
            
            # Step 3: 预处理（硬代码流程）
            clean_data = self._preprocess(raw_data, rules)
            
            # Step 4: 规则应用转换（硬代码流程）
            transformed = self._transform(clean_data, rules, context)
            
            # Step 5: 行拆分（硬代码流程）
            split_data = self._split_rows(transformed, rules)
            
            # Step 6: 行合并（硬代码流程）
            merged_data = self._merge_rows(split_data, rules)
            
            # Step 7: 分配编号（硬代码流程）
            numbered = self._assign_ids(merged_data, rules)
            
            # Step 8: 后处理（硬代码流程）
            final_data = self._postprocess(numbered, rules)
            
            # Step 9: 校验（硬代码流程 - 核心：一分钱都不能差）
            passed, validation_errors = self._validate(
                final_data, raw_data, rules, context
            )
            errors.extend(validation_errors)
            
            if not passed:
                return TransformResult(
                    output_file="",
                    total_rows=0,
                    validation_passed=False,
                    review_items=[],
                    errors=errors
                )
            
            # Step 10: 输出（硬代码流程）
            output_file = self._write_output(final_data, rules, context)
            
            # 收集复核标记
            review_items = self._collect_review_items(final_data)
            
            return TransformResult(
                output_file=output_file,
                total_rows=len(final_data),
                validation_passed=True,
                review_items=review_items,
                errors=[]
            )
            
        except ValidationError as e:
            return TransformResult(
                output_file="",
                total_rows=0,
                validation_passed=False,
                review_items=[],
                errors=[str(e)]
            )
        except Exception as e:
            return TransformResult(
                output_file="",
                total_rows=0,
                validation_passed=False,
                review_items=[],
                errors=[f"处理异常: {str(e)}"]
            )
    
    def transform_with_flow(self, 
                           flow_config: Union[List, str],
                           input_source: Any,
                           context: TransformContext) -> TransformResult:
        """
        使用流程编排执行转换
        
        Args:
            flow_config: 流程配置（列表或YAML文件路径）
            input_source: 输入源
            context: 转换上下文
        
        Returns:
            TransformResult: 转换结果
        """
        from .flow_orchestrator import FlowOrchestrator, FlowResult
        
        orchestrator = FlowOrchestrator(self)
        result = orchestrator.execute(flow_config, input_source, context)
        
        return TransformResult(
            output_file=result.output_file,
            total_rows=result.total_rows,
            validation_passed=result.success,
            review_items=result.review_items,
            errors=result.errors
        )
    
    # ========== 以下方法都是硬代码实现 ==========
    
    def _read_input(self, source: Any, context: TransformContext) -> pd.DataFrame:
        """Step 1: 读取输入 - 硬代码"""
        if not self.source_adapter.can_handle(source):
            raise ValueError(f"无法处理输入源: {source}")
        
        raw_data = self.source_adapter.read(source, context)
        
        # 记录原始数据总计（用于后续校验）
        raw_data.attrs['__loaded_at__'] = datetime.now().isoformat()
        
        return raw_data
    
    def _load_rules(self, context: TransformContext) -> Dict[str, Any]:
        """Step 2: 加载规则 - 硬代码调用，动态数据"""
        return self.rule_engine.load_rules(context)
    
    def _preprocess(self, data: pd.DataFrame, 
                    rules: Dict[str, Any]) -> pd.DataFrame:
        """Step 3: 预处理 - 硬代码"""
        # 数据清洗
        data = self._clean_data(data)
        
        # 类型转换
        data = self._convert_types(data, rules)
        
        # 异常标记
        data = self._mark_anomalies(data, rules)
        
        return data
    
    def _transform(self, data: pd.DataFrame, rules: Dict[str, Any],
                   context: TransformContext) -> pd.DataFrame:
        """Step 4: 规则应用转换 - 硬代码"""
        result_rows = []
        target_fields = self.rule_engine.get_target_fields(rules)
        
        for idx, row in data.iterrows():
            new_row = {}
            row_review_marks = []
            
            for field_name in target_fields:
                # 获取规则（动态数据）
                rule = self.rule_engine.get_field_rule(field_name, context)
                
                # 应用规则计算字段值
                field_value = self.transform_engine.apply_field_rule(
                    row, field_name, rule, context
                )
                
                new_row[field_name] = field_value.value
                
                # 记录不确定项
                if not field_value.is_certain:
                    row_review_marks.append(
                        f"字段【{field_name}】{field_value.note}，请确认"
                    )
            
            # 保存复核标记
            if row_review_marks:
                self._review_marks[idx] = row_review_marks
            
            result_rows.append(new_row)
        
        return pd.DataFrame(result_rows)
    
    def _split_rows(self, data: pd.DataFrame, 
                    rules: Dict[str, Any]) -> pd.DataFrame:
        """Step 5: 行拆分 - 硬代码"""
        split_config = rules.get("transform_config", {}).get("row_split", {})
        
        if split_config.get("enabled", False):
            return self.transform_engine.split_rows(data, rules)
        
        return data
    
    def _merge_rows(self, data: pd.DataFrame, 
                    rules: Dict[str, Any]) -> pd.DataFrame:
        """Step 6: 行合并 - 硬代码"""
        merge_config = rules.get("transform_config", {}).get("row_merge", {})
        
        if merge_config.get("enabled", False):
            return self.transform_engine.merge_rows(data, rules)
        
        return data
    
    def _assign_ids(self, data: pd.DataFrame, 
                    rules: Dict[str, Any]) -> pd.DataFrame:
        """Step 7: 分配编号 - 硬代码"""
        numbering_config = rules.get("transform_config", {}).get("numbering", {})
        
        if numbering_config.get("enabled", True):
            return self.transform_engine.assign_ids(data, rules)
        
        return data
    
    def _postprocess(self, data: pd.DataFrame, 
                     rules: Dict[str, Any]) -> pd.DataFrame:
        """Step 8: 后处理 - 硬代码"""
        # 计算派生字段
        data = self._calculate_derived_fields(data, rules)
        
        # 格式调整
        data = self._format_fields(data, rules)
        
        # 添加复核标记列
        data = self._add_review_column(data)
        
        return data
    
    def _validate(self, data: pd.DataFrame, source_data: pd.DataFrame,
                  rules: Dict[str, Any], context: TransformContext) -> Tuple[bool, List[str]]:
        """Step 9: 校验 - 硬代码（核心：一分钱都不能差）"""
        return self.validator.validate(data, source_data, rules, context)
    
    def _write_output(self, data: pd.DataFrame, rules: Dict[str, Any],
                      context: TransformContext) -> str:
        """Step 10: 输出 - 硬代码"""
        return self.output_adapter.write(data, rules, context)
    
    # ========== 辅助方法（硬代码） ==========
    
    def _clean_data(self, data: pd.DataFrame) -> pd.DataFrame:
        """数据清洗 - 硬代码"""
        # 去空行
        data = data.dropna(how="all")
        
        # 去空格（字符串列）
        for col in data.select_dtypes(include=['object']).columns:
            data[col] = data[col].astype(str).str.strip()
        
        return data.reset_index(drop=True)
    
    def _convert_types(self, data: pd.DataFrame, 
                       rules: Dict[str, Any]) -> pd.DataFrame:
        """类型转换 - 硬代码"""
        type_mapping = rules.get("input_config", {}).get("type_mapping", {})
        
        for field, dtype in type_mapping.items():
            if field in data.columns:
                if dtype == "numeric":
                    # 强制转换为数字，失败转为NaN
                    data[field] = pd.to_numeric(data[field], errors="coerce")
                elif dtype == "date":
                    # 强制转换为日期，失败转为NaT
                    data[field] = pd.to_datetime(data[field], errors="coerce")
                elif dtype == "string":
                    data[field] = data[field].astype(str)
        
        return data
    
    def _mark_anomalies(self, data: pd.DataFrame, 
                        rules: Dict[str, Any]) -> pd.DataFrame:
        """异常标记 - 硬代码"""
        # 标记转换失败的数值
        for col in data.select_dtypes(include=['float64', 'int64']).columns:
            null_mask = data[col].isna()
            if null_mask.any():
                # 记录异常但不删除
                pass
        
        return data
    
    def _calculate_derived_fields(self, data: pd.DataFrame, 
                                   rules: Dict[str, Any]) -> pd.DataFrame:
        """计算派生字段 - 硬代码"""
        derived_config = rules.get("transform_config", {}).get("derived_fields", [])
        
        for field_config in derived_config:
            name = field_config.get("name")
            formula = field_config.get("formula")
            
            if name and formula:
                try:
                    # 简单公式计算（安全评估）
                    data[name] = self._safe_eval(formula, data)
                except Exception as e:
                    data[name] = None
        
        return data
    
    def _safe_eval(self, formula: str, data: pd.DataFrame) -> pd.Series:
        """安全公式计算 - 硬代码"""
        # 只允许简单的列运算
        allowed_cols = set(data.columns)
        
        # 替换列名为实际数据
        for col in allowed_cols:
            if col in formula:
                # 这里简化处理，实际应该更严格的解析
                pass
        
        # 使用eval计算（实际生产应该更安全的方式）
        try:
            result = data.eval(formula)
            return result
        except:
            return pd.Series([None] * len(data))
    
    def _format_fields(self, data: pd.DataFrame, 
                       rules: Dict[str, Any]) -> pd.DataFrame:
        """格式调整 - 硬代码"""
        format_rules = rules.get("output_config", {}).get("format_rules", {})
        
        for field, fmt in format_rules.items():
            if field in data.columns:
                if fmt == "YYYYMMDD":
                    data[field] = pd.to_datetime(data[field]).dt.strftime("%Y%m%d")
                elif fmt == "2_decimal":
                    data[field] = data[field].round(2)
        
        return data
    
    def _add_review_column(self, data: pd.DataFrame) -> pd.DataFrame:
        """添加复核标记列 - 硬代码"""
        review_col = "复核标记"
        
        # 初始化空列
        data[review_col] = ""
        
        # 填充复核标记
        for idx, marks in self._review_marks.items():
            if idx < len(data):
                data.at[idx, review_col] = "; ".join(marks)
        
        return data
    
    def _collect_review_items(self, data: pd.DataFrame) -> List[str]:
        """收集复核标记 - 硬代码"""
        review_col = "复核标记"
        
        if review_col in data.columns:
            return data[review_col][data[review_col] != ""].tolist()
        
        return []
