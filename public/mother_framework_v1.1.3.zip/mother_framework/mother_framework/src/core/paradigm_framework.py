"""
范式框架 - 硬代码

6大范式对应的框架，每个范式有固定约束
避免AI/用户的模糊解读，确保流程合规
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional, Set
from dataclasses import dataclass
import yaml


@dataclass
class ParadigmConstraint:
    """范式约束定义"""
    name: str                           # 范式名称
    paradigm_id: str                    # 范式编号（①-⑥）
    description: str                    # 范式描述
    
    # 步骤约束
    required_steps: Set[int]            # 必须包含的步骤
    optional_steps: Set[int]            # 可选步骤
    forbidden_steps: Set[int]           # 禁止的步骤
    repeatable_steps: Set[int]          # 可重复的步骤（如多源读取）
    
    # 顺序约束
    step_order_rules: Dict[int, List[int]]  # 步骤前置要求 {step: [prerequisites]}
    
    # 配置要求
    required_configs: List[str]         # 必须提供的配置项
    optional_configs: List[str]         # 可选配置项


class ParadigmFramework(ABC):
    """
    范式框架基类 - 硬代码
    
    每个范式继承此类，定义固定约束
    """
    
    CONSTRAINT: ParadigmConstraint = None
    
    def validate_flow(self, flow_steps: List[Dict]) -> List[str]:
        """
        验证流程是否符合范式约束
        
        Returns:
            错误列表，空列表表示验证通过
        """
        errors = []
        step_ids = [s.get('step') for s in flow_steps]
        
        # 1. 检查必须步骤
        for required in self.CONSTRAINT.required_steps:
            if required not in step_ids:
                errors.append(f"缺少必须步骤: Step {required} ({self._step_name(required)})")
        
        # 2. 检查禁止步骤
        for forbidden in self.CONSTRAINT.forbidden_steps:
            if forbidden in step_ids:
                errors.append(f"范式'{self.CONSTRAINT.name}'禁止使用步骤: Step {forbidden}")
        
        # 3. 检查步骤顺序
        for step_id, prerequisites in self.CONSTRAINT.step_order_rules.items():
            if step_id in step_ids:
                step_idx = step_ids.index(step_id)
                for prereq in prerequisites:
                    if prereq in step_ids:
                        prereq_idx = step_ids.index(prereq)
                        if prereq_idx > step_idx:
                            errors.append(f"步骤顺序错误: Step {prereq} 必须在 Step {step_id} 之前")
        
        # 4. 检查重复步骤是否允许
        from collections import Counter
        step_counts = Counter(step_ids)
        for step_id, count in step_counts.items():
            if count > 1 and step_id not in self.CONSTRAINT.repeatable_steps:
                errors.append(f"步骤{step_id}不允许重复（该范式不支持多源/迭代）")
        
        return errors
    
    def get_default_flow(self) -> List[Dict]:
        """获取范式默认流程"""
        # 必须步骤 + 常用可选步骤
        default_steps = sorted(self.CONSTRAINT.required_steps | 
                              (self.CONSTRAINT.optional_steps & {3, 8, 9}))  # 常用可选
        return [{"step": s} for s in default_steps]
    
    def _step_name(self, step_id: int) -> str:
        """获取步骤名称"""
        names = {
            1: "读取输入", 2: "加载规则", 3: "预处理", 4: "字段转换",
            5: "数据拆分", 6: "数据合并", 7: "编号分配", 8: "后处理",
            9: "数据校验", 10: "输出"
        }
        return names.get(step_id, f"步骤{step_id}")
    
    @abstractmethod
    def get_paradigm_config_template(self) -> Dict:
        """返回范式配置模板（用于生成YAML）"""
        pass


# ==================== 6大范式框架（硬代码） ====================

class FormatConvertParadigm(ParadigmFramework):
    """
    范式①：格式转换
    数据提取 → 格式转换 → 系统导入
    """
    CONSTRAINT = ParadigmConstraint(
        name="格式转换",
        paradigm_id="①",
        description="从源格式转换为目标格式，支持字段映射、拆分、合并",
        
        # 必须：读取、加载、转换、校验、输出
        required_steps={1, 2, 4, 9, 10},
        
        # 可选：预处理、拆分、合并、编号、后处理
        optional_steps={3, 5, 6, 7, 8},
        
        # 禁止：无
        forbidden_steps=set(),
        
        # 可重复：无（单源转换）
        repeatable_steps=set(),
        
        # 顺序约束：加载规则必须在转换之前
        step_order_rules={
            4: [2],   # 字段转换前必须加载规则
            9: [4],   # 校验前必须转换
            10: [9]   # 输出前必须校验
        },
        
        # 配置要求
        required_configs=["field_mapping", "output_template"],
        optional_configs=["split_rules", "numbering_rules"]
    )
    
    def get_paradigm_config_template(self) -> Dict:
        return {
            "paradigm": "①",
            "name": "格式转换",
            "description": "数据提取 → 格式转换 → 系统导入",
            "default_flow": [1, 2, 3, 4, 8, 9, 10],
            "capabilities": {
                "field_mapping": "字段映射规则",
                "row_split": "可选：一对多拆分（如借贷方）",
                "row_merge": "可选：多对一合并",
                "numbering": "可选：分配序号/凭证号"
            },
            "typical_flows": ["费用预提流程", "银行对账流程", "薪资导入流程", "存货调整流程"]
        }


class MultiSourceCheckParadigm(ParadigmFramework):
    """
    范式②：多源核对
    多源数据采集 → 交叉核对 → 差异处理
    """
    CONSTRAINT = ParadigmConstraint(
        name="多源核对",
        paradigm_id="②",
        description="读取多个数据源，交叉比对，识别差异",
        
        # 必须：读取（至少2次）、转换、校验、输出
        required_steps={1, 4, 9, 10},
        
        # 可选：预处理、后处理
        optional_steps={3, 8},
        
        # 禁止：拆分、合并、编号（核对场景不需要）
        forbidden_steps={5, 6, 7},
        
        # 可重复：读取、加载规则（多源需要多次读取）
        repeatable_steps={1, 2},
        
        # 顺序约束
        step_order_rules={
            4: [1, 2],  # 转换前必须读取+加载规则
            9: [4],
            10: [9]
        },
        
        required_configs=["data_sources", "compare_keys", "compare_fields", "tolerance"],
        optional_configs=["preprocess_rules"]
    )
    
    def get_paradigm_config_template(self) -> Dict:
        return {
            "paradigm": "②",
            "name": "多源核对",
            "description": "多源数据采集 → 交叉核对 → 差异处理",
            "default_flow": [1, 2, 1, 2, 4, 9, 10],  # 两次读取
            "capabilities": {
                "multi_source": "必须：至少2个数据源",
                "cross_compare": "交叉比对（支持多字段、容差）",
                "diff_report": "输出差异报告"
            },
            "typical_flows": ["业财核对流程", "公司间对账流程", "进出口对账流程", "分成核对流程"],
            "constraints": {
                "note": "该范式禁止拆分/合并/编号，专注于数据比对"
            }
        }


class RuleCalculationParadigm(ParadigmFramework):
    """
    范式③：规则计算
    规则计算 → 分摊分配 → 凭证生成
    """
    CONSTRAINT = ParadigmConstraint(
        name="规则计算",
        paradigm_id="③",
        description="按规则公式计算，分摊到目标维度，生成结果",
        
        # 必须：读取、加载、转换、合并（分摊）、校验、输出
        required_steps={1, 2, 4, 6, 9, 10},
        
        # 可选：预处理、拆分、编号、后处理
        optional_steps={3, 5, 7, 8},
        
        # 禁止：无
        forbidden_steps=set(),
        
        # 可重复：转换、合并（迭代分摊）
        repeatable_steps={4, 6},
        
        # 顺序约束
        step_order_rules={
            6: [4],   # 合并前必须转换（计算金额）
            9: [6],   # 校验前必须合并（确保总计不变）
            10: [9]
        },
        
        required_configs=["calculation_formulas", "allocation_rules", "target_dimensions"],
        optional_configs=["iteration_rules", "numbering_rules"]
    )
    
    def get_paradigm_config_template(self) -> Dict:
        return {
            "paradigm": "③",
            "name": "规则计算",
            "description": "规则计算 → 分摊分配 → 凭证生成",
            "default_flow": [1, 2, 3, 4, 6, 9, 10],
            "capabilities": {
                "formula_calc": "公式计算（支持复杂计算逻辑）",
                "allocation": "必须：分摊到目标维度",
                "iteration": "可选：多次迭代分摊（部门→产品→渠道）",
                "voucher_gen": "生成会计凭证"
            },
            "typical_flows": ["费用分摊流程", "成本认定流程", "返利校准流程", "标准成本流程"],
            "constraints": {
                "note": "该范式必须包含分摊步骤（Step6），支持迭代"
            }
        }


class DocumentReviewParadigm(ParadigmFramework):
    """
    范式④：单据审核
    单据审核 → 规则校验 → 放行/异常标记
    """
    CONSTRAINT = ParadigmConstraint(
        name="单据审核",
        paradigm_id="④",
        description="读取待审核单据，执行规则校验，输出审核结果",
        
        # 必须：读取、加载、转换、校验、输出
        required_steps={1, 2, 4, 9, 10},
        
        # 可选：预处理
        optional_steps={3},
        
        # 禁止：拆分、合并、编号、后处理（审核场景不需要）
        forbidden_steps={5, 6, 7, 8},
        
        # 可重复：无
        repeatable_steps=set(),
        
        # 顺序约束
        step_order_rules={
            4: [2],
            9: [4],
            10: [9]
        },
        
        required_configs=["review_rules", "pass_criteria", "reject_criteria"],
        optional_configs=["ai_review_config"]
    )
    
    def get_paradigm_config_template(self) -> Dict:
        return {
            "paradigm": "④",
            "name": "单据审核",
            "description": "单据审核 → 规则校验 → 放行/异常标记",
            "default_flow": [1, 2, 3, 4, 9, 10],
            "capabilities": {
                "rule_review": "规则引擎校验",
                "ai_review": "可选：AI辅助审核",
                "pass_reject": "自动放行或标记异常"
            },
            "typical_flows": ["对公付款审核流程", "三单匹配流程", "发票校验流程", "收入确认流程"],
            "constraints": {
                "note": "该范式禁止拆分/合并/编号/后处理，专注于审核逻辑",
                "output": "输出包含：原单据 + 审核结果（通过/拒绝）+ 异常原因"
            }
        }


class ScheduledPushParadigm(ParadigmFramework):
    """
    范式⑤：定时推送
    定时/事件触发 → 自动执行 → 结果推送
    """
    CONSTRAINT = ParadigmConstraint(
        name="定时推送",
        paradigm_id="⑤",
        description="定时或事件触发，自动执行业务逻辑，推送结果",
        
        # 必须：读取、加载、转换、校验、输出
        required_steps={1, 2, 4, 9, 10},
        
        # 可选：预处理、拆分、合并、编号、后处理
        optional_steps={3, 5, 6, 7, 8},
        
        # 禁止：无
        forbidden_steps=set(),
        
        # 可重复：无
        repeatable_steps=set(),
        
        # 顺序约束
        step_order_rules={
            4: [2],
            9: [4],
            10: [9]
        },
        
        required_configs=["trigger_config", "execution_logic", "push_target"],
        optional_configs=["retry_policy", "notification_rules"]
    )
    
    def get_paradigm_config_template(self) -> Dict:
        return {
            "paradigm": "⑤",
            "name": "定时推送",
            "description": "定时/事件触发 → 自动执行 → 结果推送",
            "default_flow": [1, 2, 4, 9, 10],
            "capabilities": {
                "trigger": "定时触发（cron）或事件触发",
                "auto_execute": "自动执行业务逻辑",
                "push_result": "推送结果到下游系统"
            },
            "typical_flows": ["月结定时计提流程", "分摊任务推送流程", "BW数据抽取流程", "自动推账流程"],
            "constraints": {
                "note": "该范式需要额外的触发器配置",
                "execution": "执行失败需支持重试和告警"
            }
        }


class LedgerSystemParadigm(ParadigmFramework):
    """
    范式⑥：台账系统
    线下台账迁移 → 系统化管理 → 自动核对预警
    """
    CONSTRAINT = ParadigmConstraint(
        name="台账系统",
        paradigm_id="⑥",
        description="将线下台账迁入系统，自动计算维护，核对预警",
        
        # 必须：读取、加载、转换、校验、输出
        required_steps={1, 2, 4, 9, 10},
        
        # 可选：预处理、后处理
        optional_steps={3, 8},
        
        # 禁止：拆分、合并、编号（台账场景不需要）
        forbidden_steps={5, 6, 7},
        
        # 可重复：无
        repeatable_steps=set(),
        
        # 顺序约束
        step_order_rules={
            4: [2],
            9: [4],
            10: [9]
        },
        
        required_configs=["ledger_structure", "auto_calc_rules", "check_rules"],
        optional_configs=["warning_rules", "notification_rules"]
    )
    
    def get_paradigm_config_template(self) -> Dict:
        return {
            "paradigm": "⑥",
            "name": "台账系统",
            "description": "线下台账迁移 → 系统化管理 → 自动核对预警",
            "default_flow": [1, 2, 3, 4, 9, 10],
            "capabilities": {
                "ledger_import": "台账数据导入",
                "auto_calc": "系统自动计算维护",
                "auto_check": "自动核对",
                "warning": "异常预警"
            },
            "typical_flows": ["建店摊销台账流程", "资金计划台账流程", "工单跟踪台账流程", "费用台账流程"],
            "constraints": {
                "note": "该范式禁止拆分/合并/编号，专注于台账结构化和持续维护",
                "persistence": "数据需要持久化存储，支持增量更新"
            }
        }


# ==================== 范式注册表 ====================

PARADIGM_REGISTRY = {
    "format_convert": FormatConvertParadigm,
    "multi_source_check": MultiSourceCheckParadigm,
    "rule_calculation": RuleCalculationParadigm,
    "document_review": DocumentReviewParadigm,
    "scheduled_push": ScheduledPushParadigm,
    "ledger_system": LedgerSystemParadigm,
}


def get_paradigm_framework(paradigm_name: str) -> Optional[ParadigmFramework]:
    """获取范式框架实例"""
    paradigm_class = PARADIGM_REGISTRY.get(paradigm_name)
    if paradigm_class:
        return paradigm_class()
    return None


def list_all_paradigms() -> List[Dict]:
    """列出所有范式信息"""
    result = []
    for name, paradigm_class in PARADIGM_REGISTRY.items():
        framework = paradigm_class()
        template = framework.get_paradigm_config_template()
        result.append({
            "name": name,
            "paradigm": template["paradigm"],
            "description": template["description"],
            "typical_flows": template.get("typical_flows", [])
        })
    return result


def validate_flow_against_paradigm(flow_steps: List[Dict], paradigm_name: str) -> List[str]:
    """
    验证流程是否符合范式约束
    
    Args:
        flow_steps: 流程步骤列表
        paradigm_name: 范式名称
    
    Returns:
        错误列表，空列表表示验证通过
    """
    framework = get_paradigm_framework(paradigm_name)
    if not framework:
        return [f"未知范式: {paradigm_name}"]
    
    return framework.validate_flow(flow_steps)


def validate_flow_against_paradigms(flow_steps: List[Dict], paradigm_names: List[str]) -> List[str]:
    """
    验证流程是否符合多个范式约束（组合范式）
    
    组合范式规则：
    - 步骤只需符合至少一个范式的约束即可
    - 必须步骤：所有范式必须步骤的并集
    - 禁止步骤：只有当所有范式都禁止时才禁止
    - 可重复步骤：任一范式允许即可重复
    
    Args:
        flow_steps: 流程步骤列表
        paradigm_names: 范式名称列表，如 ["format_convert", "rule_calculation"]
    
    Returns:
        错误列表，空列表表示验证通过
    """
    if not paradigm_names:
        return ["未指定范式"]
    
    # 单范式，直接验证
    if len(paradigm_names) == 1:
        return validate_flow_against_paradigm(flow_steps, paradigm_names[0])
    
    # 获取所有范式框架
    frameworks = []
    for name in paradigm_names:
        framework = get_paradigm_framework(name)
        if not framework:
            return [f"未知范式: {name}"]
        frameworks.append(framework)
    
    errors = []
    step_ids = [s.get('step') for s in flow_steps]
    
    # 合并所有范式的约束
    all_required = set()
    all_forbidden = set()
    all_repeatable = set()
    all_optional = set()
    
    for fw in frameworks:
        all_required.update(fw.CONSTRAINT.required_steps)
        all_forbidden.update(fw.CONSTRAINT.forbidden_steps)
        all_repeatable.update(fw.CONSTRAINT.repeatable_steps)
        all_optional.update(fw.CONSTRAINT.optional_steps)
    
    # 组合范式规则：
    # 1. 必须步骤：任一范式要求的必须步骤
    for required in all_required:
        if required not in step_ids:
            errors.append(f"缺少必须步骤: Step {required} ({_step_name(required)})")
    
    # 2. 禁止步骤：只有当所有范式都禁止时才禁止
    # 计算所有范式都禁止的步骤
    universally_forbidden = all_forbidden.copy()
    for fw in frameworks:
        universally_forbidden &= fw.CONSTRAINT.forbidden_steps
    
    for forbidden in universally_forbidden:
        if forbidden in step_ids:
            paradigm_names_str = ", ".join([f.CONSTRAINT.name for f in frameworks])
            errors.append(f"步骤{forbidden}被所有范式禁止 ({paradigm_names_str})")
    
    # 3. 检查重复步骤：任一范式允许即可
    from collections import Counter
    step_counts = Counter(step_ids)
    for step_id, count in step_counts.items():
        if count > 1 and step_id not in all_repeatable:
            errors.append(f"步骤{step_id}不允许重复（当前组合范式不支持）")
    
    # 4. 检查每个步骤是否至少被一个范式支持
    for step_id in step_ids:
        supported = False
        for fw in frameworks:
            if (step_id in fw.CONSTRAINT.required_steps or 
                step_id in fw.CONSTRAINT.optional_steps):
                supported = True
                break
        if not supported:
            errors.append(f"步骤{step_id} ({_step_name(step_id)}) 不被任何范式支持")
    
    # 5. 检查顺序约束（所有范式的顺序约束都要满足）
    for fw in frameworks:
        for step_id, prerequisites in fw.CONSTRAINT.step_order_rules.items():
            if step_id in step_ids:
                step_idx = step_ids.index(step_id)
                for prereq in prerequisites:
                    if prereq in step_ids:
                        prereq_idx = step_ids.index(prereq)
                        if prereq_idx > step_idx:
                            errors.append(f"步骤顺序错误: Step {prereq} 必须在 Step {step_id} 之前")
    
    return errors


def _step_name(step_id: int) -> str:
    """获取步骤名称"""
    names = {
        1: "读取输入", 2: "加载规则", 3: "预处理", 4: "字段转换",
        5: "数据拆分", 6: "数据合并", 7: "编号分配", 8: "后处理",
        9: "数据校验", 10: "输出"
    }
    return names.get(step_id, f"步骤{step_id}")


def get_combined_paradigm_info(paradigm_names: List[str]) -> Dict:
    """
    获取组合范式的合并信息
    
    Args:
        paradigm_names: 范式名称列表
    
    Returns:
        合并后的范式信息
    """
    frameworks = [get_paradigm_framework(name) for name in paradigm_names]
    frameworks = [f for f in frameworks if f]
    
    if not frameworks:
        return {}
    
    # 合并约束
    all_required = set()
    all_optional = set()
    all_forbidden = set()
    all_repeatable = set()
    
    for fw in frameworks:
        all_required.update(fw.CONSTRAINT.required_steps)
        all_optional.update(fw.CONSTRAINT.optional_steps)
        all_forbidden.update(fw.CONSTRAINT.forbidden_steps)
        all_repeatable.update(fw.CONSTRAINT.repeatable_steps)
    
    return {
        "paradigms": paradigm_names,
        "paradigm_names": [f.CONSTRAINT.name for f in frameworks],
        "required_steps": sorted(all_required),
        "optional_steps": sorted(all_optional - all_required),
        "forbidden_steps": sorted(all_forbidden),
        "repeatable_steps": sorted(all_repeatable),
        "description": " + ".join([f.CONSTRAINT.description for f in frameworks])
    }
