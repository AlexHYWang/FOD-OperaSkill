"""
流程编排器 - 硬代码

职责：按配置顺序执行10步能力
支持：顺序、重复、条件、迭代
"""

import pandas as pd
from typing import Dict, List, Any, Callable, Optional, Union
from dataclasses import dataclass, field
import yaml
import os


@dataclass
class StepConfig:
    """步骤配置"""
    step_id: int                       # 步骤编号 1-10
    name: str = ""                      # 步骤名称
    params: Dict[str, Any] = field(default_factory=dict)  # 步骤参数
    condition: Optional[str] = None     # 执行条件（可选）
    iterations: int = 1                 # 迭代次数（可选）


@dataclass
class FlowResult:
    """流程执行结果"""
    success: bool
    output_file: str = ""
    total_rows: int = 0
    review_items: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    execution_log: List[Dict] = field(default_factory=list)


class FlowOrchestrator:
    """
    流程编排器 - 硬代码
    
    职责：按配置顺序执行10步能力
    支持：顺序、重复、条件、迭代
    """
    
    # 步骤名称映射
    STEP_NAMES = {
        1: "读取输入",
        2: "加载规则",
        3: "预处理",
        4: "字段转换",
        5: "数据拆分",
        6: "数据合并",
        7: "编号分配",
        8: "后处理",
        9: "数据校验",
        10: "输出"
    }
    
    def __init__(self, transformer):
        """
        初始化
        
        Args:
            transformer: DataTransformer实例（提供10步能力）
        """
        self.transformer = transformer
        self.data: Optional[pd.DataFrame] = None      # 当前数据
        self.source_data: Optional[pd.DataFrame] = None  # 原始数据（用于校验）
        self.rules: Optional[Dict] = None             # 当前规则
        self.context: Optional[Any] = None            # 上下文
        self.execution_log: List[Dict] = []           # 执行日志
        
        # 步骤编号 → 方法映射
        self._step_methods: Dict[int, Callable] = {
            1: self._step_read_input,
            2: self._step_load_rules,
            3: self._step_preprocess,
            4: self._step_transform,
            5: self._step_split_rows,
            6: self._step_merge_rows,
            7: self._step_assign_ids,
            8: self._step_postprocess,
            9: self._step_validate,
            10: self._step_write_output,
        }
    
    def execute(self, flow_config: Union[List, str, Dict], 
                input_source: Any, 
                context: Any,
                paradigms: List[str] = None) -> FlowResult:
        """
        执行编排好的流程
        
        Args:
            flow_config: 流程配置列表、YAML文件路径或完整配置字典
            input_source: 输入源
            context: 转换上下文
            paradigms: 范式列表（可选，用于组合范式验证）
        
        Returns:
            FlowResult: 执行结果
        """
        self.context = context
        self.execution_log = []
        
        # 加载流程配置
        if isinstance(flow_config, str):
            steps, paradigms_from_file = self._load_flow_from_file(flow_config)
            # 如果文件中有paradigms配置，使用它
            if paradigms_from_file and not paradigms:
                paradigms = paradigms_from_file
        elif isinstance(flow_config, dict):
            # 完整配置字典
            steps = flow_config.get('steps', [])
            paradigms = paradigms or flow_config.get('paradigms', flow_config.get('paradigm', []))
            if isinstance(paradigms, str):
                paradigms = [paradigms]
        else:
            steps = flow_config
        
        # 验证组合范式约束
        if paradigms:
            from .paradigm_framework import validate_flow_against_paradigms
            errors = validate_flow_against_paradigms(steps, paradigms)
            if errors:
                return FlowResult(
                    success=False,
                    errors=[f"范式验证失败: {e}" for e in errors],
                    execution_log=self.execution_log
                )
        
        try:
            # 执行每个步骤
            for idx, step_cfg in enumerate(steps):
                step = self._parse_step(step_cfg, idx)
                
                # 检查条件
                if step.condition and not self._eval_condition(step.condition):
                    self._log_step(step, "skipped", "条件不满足")
                    continue
                
                # 执行步骤（支持迭代）
                for iteration in range(step.iterations):
                    result = self._execute_step(step, input_source, iteration)
                    
                    # 如果是输出步骤，返回结果
                    if step.step_id == 10 and result:
                        return FlowResult(
                            success=True,
                            output_file=result,
                            total_rows=len(self.data) if self.data is not None else 0,
                            review_items=self._collect_review_items(),
                            execution_log=self.execution_log
                        )
            
            # 如果没有输出步骤，返回失败
            return FlowResult(
                success=False,
                errors=["流程配置缺少输出步骤"],
                execution_log=self.execution_log
            )
            
        except Exception as e:
            return FlowResult(
                success=False,
                errors=[str(e)],
                execution_log=self.execution_log
            )
    
    def _load_flow_from_file(self, filepath: str) -> tuple:
        """
        从YAML文件加载流程配置
        
        Returns:
            (steps, paradigms) 元组
        """
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"流程配置文件不存在: {filepath}")
        
        with open(filepath, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        steps = config.get('steps', [])
        
        # 支持 paradigms 列表或单个 paradigm
        paradigms = config.get('paradigms', [])
        if not paradigms:
            single_paradigm = config.get('paradigm')
            if single_paradigm:
                paradigms = [single_paradigm] if isinstance(single_paradigm, str) else single_paradigm
        
        return steps, paradigms
    
    def _parse_step(self, step_cfg: Union[int, Dict, List], 
                    index: int) -> StepConfig:
        """解析步骤配置"""
        # 简写：单个数字 [1, 2, 3]
        if isinstance(step_cfg, int):
            return StepConfig(
                step_id=step_cfg,
                name=self.STEP_NAMES.get(step_cfg, f"步骤{step_cfg}"),
                params={}
            )
        
        # 简写：列表展开 [[1, 2, 3]] → 顺序执行
        if isinstance(step_cfg, list):
            # 这种情况在execute中处理，这里只返回第一个
            if len(step_cfg) > 0:
                return self._parse_step(step_cfg[0], index)
            else:
                raise ValueError("空列表步骤配置")
        
        # 完整配置
        if isinstance(step_cfg, dict):
            # 处理简写列表 [[1, 2, 3]]
            if 'steps' in step_cfg:
                return self._parse_step(step_cfg['steps'][0], index)
            
            step_id = step_cfg.get('step')
            if step_id is None:
                raise ValueError(f"步骤配置缺少'step'字段: {step_cfg}")
            
            return StepConfig(
                step_id=step_id,
                name=step_cfg.get('name', self.STEP_NAMES.get(step_id, f"步骤{step_id}")),
                params=step_cfg.get('params', {}),
                condition=step_cfg.get('condition'),
                iterations=step_cfg.get('iterations', 1)
            )
        
        raise ValueError(f"未知的步骤配置格式: {step_cfg}")
    
    def _execute_step(self, step: StepConfig, 
                      input_source: Any, 
                      iteration: int) -> Any:
        """执行单个步骤"""
        method = self._step_methods.get(step.step_id)
        
        if not method:
            raise ValueError(f"未知步骤: {step.step_id}")
        
        # 执行
        try:
            result = method(step.params, input_source, iteration)
            self._log_step(step, "success", f"迭代{iteration+1}/{step.iterations}")
            return result
        except Exception as e:
            self._log_step(step, "failed", str(e))
            raise
    
    def _log_step(self, step: StepConfig, status: str, message: str):
        """记录步骤执行日志"""
        self.execution_log.append({
            'step_id': step.step_id,
            'step_name': step.name,
            'status': status,
            'message': message
        })
    
    def _eval_condition(self, condition: str) -> bool:
        """评估条件"""
        # 安全评估：只允许访问data, rules, context
        safe_dict = {
            'data': self.data,
            'rules': self.rules,
            'context': self.context,
            'has_data': self.data is not None and len(self.data) > 0,
            'has_rules': self.rules is not None
        }
        
        try:
            return eval(condition, {"__builtins__": {}}, safe_dict)
        except Exception as e:
            print(f"条件评估失败: {condition}, 错误: {e}")
            return True  # 默认执行
    
    def _collect_review_items(self) -> List[str]:
        """收集复核标记"""
        if self.data is None:
            return []
        
        review_col = "复核标记"
        if review_col in self.data.columns:
            return self.data[review_col][self.data[review_col] != ""].tolist()
        return []
    
    # ========== 10步能力封装 ==========
    
    def _step_read_input(self, params: Dict, input_source: Any, iteration: int) -> pd.DataFrame:
        """Step 1: 读取输入"""
        source = params.get('source', input_source)
        self.data = self.transformer.source_adapter.read(source, self.context)
        
        # 保存原始数据用于校验
        if self.source_data is None:
            self.source_data = self.data.copy()
        
        return self.data
    
    def _step_load_rules(self, params: Dict, input_source: Any, iteration: int) -> Dict:
        """Step 2: 加载规则"""
        rules_name = params.get('rules')  # 可指定加载特定规则包
        
        if rules_name:
            # 临时修改context加载特定规则
            original_type = self.context.business_type
            self.context.business_type = rules_name
            self.rules = self.transformer.rule_engine.load_rules(self.context)
            self.context.business_type = original_type
        else:
            self.rules = self.transformer.rule_engine.load_rules(self.context)
        
        return self.rules
    
    def _step_preprocess(self, params: Dict, input_source: Any, iteration: int) -> pd.DataFrame:
        """Step 3: 预处理"""
        self.data = self.transformer._preprocess(self.data, self.rules)
        return self.data
    
    def _step_transform(self, params: Dict, input_source: Any, iteration: int) -> pd.DataFrame:
        """Step 4: 字段转换"""
        self.data = self.transformer._transform(self.data, self.rules, self.context)
        return self.data
    
    def _step_split_rows(self, params: Dict, input_source: Any, iteration: int) -> pd.DataFrame:
        """Step 5: 数据拆分"""
        # 合并params到rules
        if params:
            self.rules.setdefault('transform_config', {}).setdefault('row_split', {}).update(params)
            self.rules['transform_config']['row_split']['enabled'] = True
        
        self.data = self.transformer._split_rows(self.data, self.rules)
        return self.data
    
    def _step_merge_rows(self, params: Dict, input_source: Any, iteration: int) -> pd.DataFrame:
        """Step 6: 数据合并"""
        if params:
            self.rules.setdefault('transform_config', {}).setdefault('row_merge', {}).update(params)
            self.rules['transform_config']['row_merge']['enabled'] = True
        
        self.data = self.transformer._merge_rows(self.data, self.rules)
        return self.data
    
    def _step_assign_ids(self, params: Dict, input_source: Any, iteration: int) -> pd.DataFrame:
        """Step 7: 编号分配"""
        if params:
            self.rules.setdefault('transform_config', {}).setdefault('numbering', {}).update(params)
            self.rules['transform_config']['numbering']['enabled'] = True
        
        self.data = self.transformer._assign_ids(self.data, self.rules)
        return self.data
    
    def _step_postprocess(self, params: Dict, input_source: Any, iteration: int) -> pd.DataFrame:
        """Step 8: 后处理"""
        self.data = self.transformer._postprocess(self.data, self.rules)
        return self.data
    
    def _step_validate(self, params: Dict, input_source: Any, iteration: int) -> bool:
        """Step 9: 数据校验"""
        passed, errors = self.transformer.validator.validate(
            self.data, self.source_data, self.rules, self.context
        )
        
        if not passed:
            raise ValidationError(f"校验失败: {'; '.join(errors)}")
        
        return True
    
    def _step_write_output(self, params: Dict, input_source: Any, iteration: int) -> str:
        """Step 10: 输出"""
        # 合并params到rules
        if params:
            self.rules.setdefault('output_config', {}).update(params)
        
        output_file = self.transformer.output_adapter.write(
            self.data, self.rules, self.context
        )
        return output_file


class ValidationError(Exception):
    """校验错误"""
    pass
