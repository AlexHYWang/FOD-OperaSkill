"""
核心抽象接口定义
硬代码：接口结构固定，定义整个骨架的契约
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Any, Tuple, Optional, Union
from dataclasses import dataclass, field
from datetime import datetime
import pandas as pd


@dataclass
class TransformContext:
    """转换上下文 - 硬代码数据结构"""
    business_type: str
    source_system: str
    target_system: str
    period: str
    operator: str = ""
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class FieldValue:
    """字段值结果 - 硬代码数据结构"""
    value: Any
    is_certain: bool
    note: str = ""


@dataclass
class TransformResult:
    """转换结果 - 硬代码数据结构"""
    output_file: str
    total_rows: int
    validation_passed: bool
    review_items: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


@dataclass
class ValidationError:
    """校验错误 - 硬代码数据结构"""
    errors: List[str]

    def __str__(self):
        return "; ".join(self.errors)


class SourceAdapter(ABC):
    """输入适配器接口 - 硬代码"""
    
    @abstractmethod
    def can_handle(self, source: Any) -> bool:
        """能否处理该输入源"""
        pass
    
    @abstractmethod
    def read(self, source: Any, context: TransformContext) -> pd.DataFrame:
        """读取并标准化为内部数据结构"""
        pass
    
    @abstractmethod
    def detect_schema(self, raw_data: pd.DataFrame) -> Dict[str, Any]:
        """自动识别字段结构"""
        pass


class RuleEngine(ABC):
    """规则引擎接口 - 硬代码"""
    
    @abstractmethod
    def load_rules(self, context: TransformContext) -> Dict[str, Any]:
        """加载所有规则（热更新）"""
        pass
    
    @abstractmethod
    def get_field_rule(self, field_name: str, context: TransformContext) -> str:
        """获取字段规则：特殊 > 通用 > 默认"""
        pass
    
    @abstractmethod
    def lookup_mapping(self, dict_name: str, key: str, 
                       context: TransformContext) -> FieldValue:
        """查询映射字典"""
        pass
    
    @abstractmethod
    def get_target_fields(self, rules: Dict[str, Any]) -> List[str]:
        """获取目标字段列表"""
        pass


class TransformEngine(ABC):
    """转换引擎接口 - 硬代码"""
    
    @abstractmethod
    def transform(self, data: pd.DataFrame, rules: Dict[str, Any],
                  context: TransformContext) -> pd.DataFrame:
        """执行完整转换流程"""
        pass
    
    @abstractmethod
    def apply_field_rule(self, row: pd.Series, field_name: str,
                         rule: str, context: TransformContext) -> FieldValue:
        """应用单个字段规则"""
        pass
    
    @abstractmethod
    def split_rows(self, data: pd.DataFrame, rules: Dict[str, Any]) -> pd.DataFrame:
        """行拆分（一对多）"""
        pass
    
    @abstractmethod
    def merge_rows(self, data: pd.DataFrame, rules: Dict[str, Any]) -> pd.DataFrame:
        """行合并（多对一）"""
        pass
    
    @abstractmethod
    def get_field_value(self, field_name: str, row: pd.Series, 
                        rules: Dict[str, Any], context: TransformContext) -> FieldValue:
        """按规则取字段值（特殊规则优先于通用规则）"""
        pass
    
    @abstractmethod
    def assign_ids(self, data: pd.DataFrame, rules: Dict[str, Any]) -> pd.DataFrame:
        """分配编号（批次号、序号）"""
        pass


class Validator(ABC):
    """校验器接口 - 硬代码"""
    
    @abstractmethod
    def validate(self, data: pd.DataFrame, source_data: pd.DataFrame,
                 rules: Dict[str, Any], context: TransformContext) -> Tuple[bool, List[str]]:
        """执行所有校验"""
        pass
    
    @abstractmethod
    def check_balance(self, data: pd.DataFrame, rules: Dict[str, Any]) -> List[str]:
        """平衡校验"""
        pass
    
    @abstractmethod
    def check_total_match(self, source_total: float, 
                          target_total: float, tolerance: float) -> List[str]:
        """总计匹配校验"""
        pass
    
    @abstractmethod
    def check_required_fields(self, data: pd.DataFrame, 
                              fields: List[str]) -> List[str]:
        """必填字段校验"""
        pass
    
    @abstractmethod
    def check_format(self, data: pd.DataFrame, 
                     format_rules: Dict[str, str]) -> List[str]:
        """格式校验"""
        pass


class OutputAdapter(ABC):
    """输出适配器接口 - 硬代码"""
    
    @abstractmethod
    def write(self, data: pd.DataFrame, rules: Dict[str, Any],
              context: TransformContext) -> str:
        """写入输出文件"""
        pass
    
    @abstractmethod
    def apply_template(self, data: pd.DataFrame, 
                       template: Any) -> pd.DataFrame:
        """应用模板格式"""
        pass
    
    @abstractmethod
    def generate_filename(self, context: TransformContext, 
                          rules: Dict[str, Any]) -> str:
        """生成输出文件名"""
        pass
