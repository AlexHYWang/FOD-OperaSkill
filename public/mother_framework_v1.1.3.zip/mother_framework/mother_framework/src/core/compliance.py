"""
合规检查模块 - 母框架宪法执行

职责：
1. 检测与母框架的冲突
2. 记录突破点
3. 强制执行宪法条款
"""

from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class ViolationStatus(Enum):
    """突破状态"""
    PENDING = "pending"      # 待审批
    APPROVED = "approved"    # 已批准
    REJECTED = "rejected"    # 已拒绝


@dataclass
class ConstitutionViolation:
    """宪法违规记录"""
    article: str                    # 宪法条款编号（如"第三条"）
    clause: str                     # 具体条款
    violation: str                  # 冲突描述
    justification: str = ""         # 突破理由
    approved_by: str = ""           # 审批人
    approved_at: str = ""           # 审批时间
    status: ViolationStatus = ViolationStatus.PENDING
    
    def to_dict(self) -> Dict:
        return {
            "article": self.article,
            "clause": self.clause,
            "violation": self.violation,
            "justification": self.justification,
            "approved_by": self.approved_by,
            "approved_at": self.approved_at,
            "status": self.status.value
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'ConstitutionViolation':
        return cls(
            article=data.get("article", ""),
            clause=data.get("clause", ""),
            violation=data.get("violation", ""),
            justification=data.get("justification", ""),
            approved_by=data.get("approved_by", ""),
            approved_at=data.get("approved_at", ""),
            status=ViolationStatus(data.get("status", "pending"))
        )


@dataclass
class ComplianceReport:
    """合规检查报告"""
    is_compliant: bool                              # 是否完全合规
    violations: List[ConstitutionViolation]         # 违规列表
    required_breakthroughs: List[ConstitutionViolation]  # 需要突破的项
    
    def __post_init__(self):
        if self.required_breakthroughs is None:
            self.required_breakthroughs = []
    
    def to_dict(self) -> Dict:
        return {
            "is_compliant": self.is_compliant,
            "violations": [v.to_dict() for v in self.violations],
            "required_breakthroughs": [v.to_dict() for v in self.required_breakthroughs]
        }


class ConstitutionChecker:
    """
    宪法检查器
    
    检查具体实现是否与母框架宪法冲突
    """
    
    # 宪法条款定义
    ARTICLES = {
        "第一条": "三层架构不可侵犯",
        "第二条": "10步流程神圣不可变更",
        "第三条": "范式约束必须遵守",
        "第四条": "组合范式规则",
        "第五条": "一分钱都不能差",
        "第六条": "红线规则",
        "第七条": "突破条款"
    }
    
    def __init__(self):
        self.violations: List[ConstitutionViolation] = []
    
    def check_paradigm_compliance(self, flow_steps: List[Dict], 
                                   paradigm_names: List[str]) -> ComplianceReport:
        """
        检查流程是否符合范式约束（宪法第三条）
        
        Args:
            flow_steps: 流程步骤
            paradigm_names: 范式列表
        
        Returns:
            ComplianceReport: 合规报告
        """
        from .paradigm_framework import validate_flow_against_paradigms
        
        errors = validate_flow_against_paradigms(flow_steps, paradigm_names)
        
        violations = []
        for error in errors:
            violations.append(ConstitutionViolation(
                article="第三条",
                clause="范式约束",
                violation=error
            ))
        
        return ComplianceReport(
            is_compliant=len(violations) == 0,
            violations=violations,
            required_breakthroughs=violations.copy() if violations else []
        )
    
    def check_step_sequence(self, flow_steps: List[Dict]) -> ComplianceReport:
        """
        检查步骤顺序是否合理（宪法第二条）
        
        Args:
            flow_steps: 流程步骤
        
        Returns:
            ComplianceReport: 合规报告
        """
        violations = []
        step_ids = [s.get('step') for s in flow_steps]
        
        # 检查必须步骤是否存在
        required_steps = {1, 2, 4, 9, 10}
        missing = required_steps - set(step_ids)
        
        for step_id in missing:
            violations.append(ConstitutionViolation(
                article="第二条",
                clause="10步流程",
                violation=f"缺少必须步骤: Step {step_id}"
            ))
        
        return ComplianceReport(
            is_compliant=len(violations) == 0,
            violations=violations,
            required_breakthroughs=violations.copy() if violations else []
        )
    
    def check_combined_paradigms(self, paradigm_names: List[str]) -> ComplianceReport:
        """
        检查组合范式是否合法（宪法第四条）
        
        Args:
            paradigm_names: 范式名称列表
        
        Returns:
            ComplianceReport: 合规报告
        """
        from .paradigm_framework import PARADIGM_REGISTRY
        
        violations = []
        
        for name in paradigm_names:
            if name not in PARADIGM_REGISTRY:
                violations.append(ConstitutionViolation(
                    article="第四条",
                    clause="组合范式规则",
                    violation=f"未知范式: {name}"
                ))
        
        return ComplianceReport(
            is_compliant=len(violations) == 0,
            violations=violations,
            required_breakthroughs=violations.copy() if violations else []
        )
    
    def full_compliance_check(self, flow_config: Dict) -> ComplianceReport:
        """
        完整合规检查
        
        Args:
            flow_config: 流程配置字典
        
        Returns:
            ComplianceReport: 完整合规报告
        """
        all_violations = []
        
        steps = flow_config.get('steps', [])
        paradigms = flow_config.get('paradigms', [])
        if not paradigms:
            single = flow_config.get('paradigm')
            if single:
                paradigms = [single] if isinstance(single, str) else single
        
        # 检查范式约束
        if paradigms:
            report = self.check_paradigm_compliance(steps, paradigms)
            all_violations.extend(report.violations)
        
        # 检查步骤顺序
        report = self.check_step_sequence(steps)
        all_violations.extend(report.violations)
        
        # 检查组合范式
        if len(paradigms) > 1:
            report = self.check_combined_paradigms(paradigms)
            all_violations.extend(report.violations)
        
        return ComplianceReport(
            is_compliant=len(all_violations) == 0,
            violations=all_violations,
            required_breakthroughs=all_violations.copy() if all_violations else []
        )


class BreakthroughRecorder:
    """
    突破记录器
    
    记录和管理所有宪法突破
    """
    
    def __init__(self, skill_name: str):
        """
        初始化
        
        Args:
            skill_name: 子SKILL名称
        """
        self.skill_name = skill_name
        self.violations: List[ConstitutionViolation] = []
    
    def add_violation(self, violation: ConstitutionViolation):
        """添加违规记录"""
        self.violations.append(violation)
    
    def approve_violation(self, index: int, approved_by: str, 
                          justification: str) -> bool:
        """
        批准突破
        
        Args:
            index: 违规记录索引
            approved_by: 审批人
            justification: 突破理由
        
        Returns:
            bool: 是否成功
        """
        if 0 <= index < len(self.violations):
            v = self.violations[index]
            v.status = ViolationStatus.APPROVED
            v.approved_by = approved_by
            v.approved_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            v.justification = justification
            return True
        return False
    
    def reject_violation(self, index: int, reason: str) -> bool:
        """
        拒绝突破
        
        Args:
            index: 违规记录索引
            reason: 拒绝理由
        
        Returns:
            bool: 是否成功
        """
        if 0 <= index < len(self.violations):
            v = self.violations[index]
            v.status = ViolationStatus.REJECTED
            v.justification = reason
            return True
        return False
    
    def has_pending_violations(self) -> bool:
        """是否有待审批的违规"""
        return any(v.status == ViolationStatus.PENDING for v in self.violations)
    
    def has_approved_violations(self) -> bool:
        """是否有已批准的违规"""
        return any(v.status == ViolationStatus.APPROVED for v in self.violations)
    
    def get_pending_violations(self) -> List[ConstitutionViolation]:
        """获取待审批的违规"""
        return [v for v in self.violations if v.status == ViolationStatus.PENDING]
    
    def to_yaml(self) -> str:
        """导出为YAML格式"""
        import yaml
        
        data = {
            "skill_name": self.skill_name,
            "constitution_version": "1.0.0",
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "constitution_violations": [v.to_dict() for v in self.violations]
        }
        
        return yaml.dump(data, allow_unicode=True, sort_keys=False)
    
    def save_to_file(self, filepath: str):
        """保存到文件"""
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(self.to_yaml())
    
    @classmethod
    def load_from_file(cls, filepath: str) -> 'BreakthroughRecorder':
        """从文件加载"""
        import yaml
        
        with open(filepath, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        
        recorder = cls(data.get("skill_name", "unknown"))
        
        for v_data in data.get("constitution_violations", []):
            recorder.violations.append(ConstitutionViolation.from_dict(v_data))
        
        return recorder


def require_breakthrough_approval(checker: ConstitutionChecker,
                                   flow_config: Dict,
                                   skill_name: str) -> Tuple[bool, BreakthroughRecorder]:
    """
    要求突破审批
    
    如果发现与母框架冲突，停止执行并返回冲突报告
    用户需要审批后才能继续
    
    Args:
        checker: 宪法检查器
        flow_config: 流程配置
        skill_name: 子SKILL名称
    
    Returns:
        (bool, BreakthroughRecorder): (是否可以直接执行, 突破记录器)
        - 如果可以直接执行，返回 (True, recorder)
        - 如果有冲突需要审批，返回 (False, recorder)
    """
    report = checker.full_compliance_check(flow_config)
    recorder = BreakthroughRecorder(skill_name)
    
    if report.is_compliant:
        # 完全合规，无需突破
        return True, recorder
    
    # 有冲突，需要记录
    for violation in report.violations:
        recorder.add_violation(violation)
    
    # 返回需要审批
    return False, recorder
