"""
组合范式使用示例

演示如何：
1. 验证流程是否符合组合范式约束
2. 获取组合范式信息
3. 执行组合范式流程
"""

import sys
sys.path.insert(0, '/mnt/okcomputer/output/mother_framework')

from src.core.paradigm_framework import (
    validate_flow_against_paradigms,
    get_combined_paradigm_info,
    list_all_paradigms
)


def demo_list_paradigms():
    """列出所有可用范式"""
    print("=" * 60)
    print("可用范式列表")
    print("=" * 60)
    
    paradigms = list_all_paradigms()
    for p in paradigms:
        print(f"\n{p['paradigm']} {p['name']}")
        print(f"  描述: {p['description']}")
        print(f"  典型流程: {', '.join(p['typical_flows'][:3])}")


def demo_combined_paradigm_info():
    """演示获取组合范式信息"""
    print("\n" + "=" * 60)
    print("组合范式信息示例")
    print("=" * 60)
    
    # ①+③ 组合
    print("\n【范式①+③：格式转换 + 规则计算】")
    info = get_combined_paradigm_info(["format_convert", "rule_calculation"])
    print(f"  范式: {info['paradigm_names']}")
    print(f"  必须步骤: {info['required_steps']}")
    print(f"  可选步骤: {info['optional_steps']}")
    print(f"  可重复步骤: {info['repeatable_steps']}")
    
    # ①+② 组合
    print("\n【范式①+②：格式转换 + 多源核对】")
    info = get_combined_paradigm_info(["format_convert", "multi_source_check"])
    print(f"  范式: {info['paradigm_names']}")
    print(f"  必须步骤: {info['required_steps']}")
    print(f"  禁止步骤: {info['forbidden_steps']}")
    print(f"  可重复步骤: {info['repeatable_steps']}")


def demo_validate_single_paradigm():
    """验证单范式"""
    print("\n" + "=" * 60)
    print("单范式验证示例")
    print("=" * 60)
    
    # 范式③的正确流程
    flow_steps = [
        {"step": 1, "name": "读取输入"},
        {"step": 2, "name": "加载规则"},
        {"step": 4, "name": "字段转换"},
        {"step": 6, "name": "数据合并"},  # 范式③必须
        {"step": 9, "name": "数据校验"},
        {"step": 10, "name": "输出"}
    ]
    
    from src.core.paradigm_framework import validate_flow_against_paradigm
    
    print("\n验证范式③（规则计算）...")
    errors = validate_flow_against_paradigm(flow_steps, "rule_calculation")
    if errors:
        print(f"  ✗ 验证失败: {errors}")
    else:
        print("  ✓ 验证通过")
    
    # 缺少必须步骤的错误示例
    bad_flow = [
        {"step": 1}, {"step": 2}, {"step": 4}, 
        # 缺少 Step 6（合并）
        {"step": 9}, {"step": 10}
    ]
    
    print("\n验证缺少Step 6的流程...")
    errors = validate_flow_against_paradigm(bad_flow, "rule_calculation")
    if errors:
        print(f"  ✗ 验证失败（预期）:")
        for e in errors:
            print(f"    - {e}")


def demo_validate_combined_paradigm():
    """验证组合范式"""
    print("\n" + "=" * 60)
    print("组合范式验证示例")
    print("=" * 60)
    
    # ①+③ 组合的正确流程
    flow_steps = [
        {"step": 1, "name": "读取HR费用数据"},
        {"step": 2, "name": "加载分摊规则"},
        {"step": 3, "name": "数据清洗"},       # ①可选
        {"step": 4, "name": "字段映射"},       # ①必须
        {"step": 4, "name": "计算分摊金额"},   # ③必须（可重复）
        {"step": 6, "name": "按维度合并"},     # ③必须
        {"step": 7, "name": "分配凭证号"},     # ①可选
        {"step": 8, "name": "生成借贷方"},     # ①可选
        {"step": 9, "name": "数据校验"},       # ①+③共同
        {"step": 10, "name": "输出SAP凭证"}    # ①+③共同
    ]
    
    print("\n【验证①+③组合：费用预提分摊】")
    print(f"  流程步骤: {[s['step'] for s in flow_steps]}")
    
    errors = validate_flow_against_paradigms(
        flow_steps, 
        ["format_convert", "rule_calculation"]
    )
    
    if errors:
        print(f"  ✗ 验证失败:")
        for e in errors:
            print(f"    - {e}")
    else:
        print("  ✓ 组合范式验证通过")
        print("  说明：所有步骤都被至少一个范式支持")
    
    # ①+② 组合示例
    print("\n【验证①+②组合：银行对账】")
    bank_flow = [
        {"step": 1, "name": "读取银行流水"},
        {"step": 2, "name": "加载银行规则"},
        {"step": 1, "name": "读取ERP数据"},    # ②要求多源读取
        {"step": 2, "name": "加载ERP规则"},
        {"step": 4, "name": "统一字段格式"},
        {"step": 4, "name": "交叉比对"},
        {"step": 9, "name": "核对结果校验"},
        {"step": 10, "name": "输出差异报告"}
    ]
    
    print(f"  流程步骤: {[s['step'] for s in bank_flow]}")
    
    errors = validate_flow_against_paradigms(
        bank_flow,
        ["format_convert", "multi_source_check"]
    )
    
    if errors:
        print(f"  ✗ 验证失败:")
        for e in errors:
            print(f"    - {e}")
    else:
        print("  ✓ 组合范式验证通过")
        print("  说明：Step 1重复2次，符合范式②多源核对要求")


def demo_combined_paradigm_rules():
    """演示组合范式规则"""
    print("\n" + "=" * 60)
    print("组合范式规则说明")
    print("=" * 60)
    
    print("""
组合范式验证规则：

1. 必须步骤（并集）
   - 范式①必须: [1, 2, 4, 9, 10]
   - 范式③必须: [1, 2, 4, 6, 9, 10]
   - 组合必须: [1, 2, 4, 6, 9, 10]（并集）

2. 禁止步骤（交集）
   - 范式②禁止: [5, 6, 7]
   - 范式①禁止: []
   - 组合禁止: []（交集为空，因为范式①允许所有）

3. 可重复步骤（并集）
   - 范式②允许重复: [1, 2]
   - 范式①允许重复: []
   - 组合允许: [1, 2]（并集）

4. 步骤支持检查
   - 每个步骤只需被至少一个范式支持
   - Step 6（合并）被范式③支持，范式①不禁止
   - 所以Step 6在①+③组合中是允许的
""")


def demo_yaml_flow_validation():
    """从YAML文件验证流程"""
    print("\n" + "=" * 60)
    print("YAML流程配置验证")
    print("=" * 60)
    
    import yaml
    import os
    
    flow_dir = "/mnt/okcomputer/output/mother_framework/flows"
    
    # 检查示例文件
    example_files = [
        "paradigm_01_03_combined/expense_allocation_with_voucher.yaml",
        "paradigm_01_02_combined/bank_reconciliation.yaml",
        "paradigm_03_05_combined/month_end_accrual.yaml"
    ]
    
    for filename in example_files:
        filepath = os.path.join(flow_dir, filename)
        if os.path.exists(filepath):
            print(f"\n验证: {filename}")
            
            with open(filepath, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            
            paradigms = config.get('paradigms', [config.get('paradigm')])
            steps = config.get('steps', [])
            
            print(f"  范式: {paradigms}")
            print(f"  步骤: {[s['step'] for s in steps]}")
            
            errors = validate_flow_against_paradigms(steps, paradigms)
            if errors:
                print(f"  ✗ 验证失败: {errors}")
            else:
                print(f"  ✓ 验证通过")


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("母框架 - 组合范式演示")
    print("=" * 60)
    
    demo_list_paradigms()
    demo_combined_paradigm_info()
    demo_validate_single_paradigm()
    demo_validate_combined_paradigm()
    demo_combined_paradigm_rules()
    demo_yaml_flow_validation()
    
    print("\n" + "=" * 60)
    print("演示完成")
    print("=" * 60)
