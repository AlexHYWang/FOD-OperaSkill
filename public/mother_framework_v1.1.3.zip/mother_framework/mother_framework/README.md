# 数据转换批处理母框架

**版本**: v1.0.0  
**定位**: 所有具体业务处理的"宪法"约束

---

## 快速理解

这个母框架就像**宪法**，它：
- 定义了国家（框架）的基本结构
- 规定了不能触碰的红线
- 但不规定具体的法律细节

基于母框架的具体业务实现就像**具体法律**：
- 必须遵守宪法
- 在宪法框架内制定具体规则

---

## 核心结构

```
母框架 (mother_framework/)
├── CONSTITUTION.md          # 宪法文件（必须遵守的约束）
├── README.md                # 本文件
└── src/                     # 核心骨架（不可修改）
    ├── __init__.py          # 框架入口
    └── core/                # 核心模块
        ├── interfaces.py    # 抽象接口（供实现）
        ├── transformer.py   # 10步流程骨架
        ├── flow_orchestrator.py  # 流程编排器
        ├── paradigm_framework.py # 6大范式约束
        └── compliance.py    # 合规检查（宪法执行）
```

---

## 使用方式

### 方式1：作为依赖引入

```python
# 将母框架加入Python路径
import sys
sys.path.insert(0, '/path/to/mother_framework')

from mother_framework import (
    DataTransformer,
    TransformContext,
    SourceAdapter,      # 需要实现
    OutputAdapter,      # 需要实现
    RuleEngine,         # 需要实现
    TransformEngine,    # 需要实现
    Validator,          # 需要实现
    validate_flow_against_paradigm
)
```

### 方式2：创建具体业务包

```
my_business_package/
├── mother_framework/          # 母框架（复制或引用）
│   └── src/
├── adapters/                  # 具体适配器实现
│   ├── __init__.py
│   ├── excel_source.py        # 实现 SourceAdapter
│   └── excel_output.py        # 实现 OutputAdapter
├── engine/                    # 具体引擎实现
│   ├── __init__.py
│   ├── file_rule_engine.py    # 实现 RuleEngine
│   ├── transform_engine.py    # 实现 TransformEngine
│   └── validation_engine.py   # 实现 Validator
├── flows/                     # 具体流程配置
│   └── paradigm_01/
│       └── my_flow.yaml
├── rules/                     # 具体规则数据
│   └── field_rules.xlsx
└── main.py                    # 业务入口
```

---

## 扩展示例

### 1. 实现适配器

```python
# adapters/excel_source.py
from mother_framework import SourceAdapter, TransformContext
import pandas as pd

class ExcelSourceAdapter(SourceAdapter):
    """Excel输入适配器"""
    
    def can_handle(self, source) -> bool:
        return str(source).endswith(('.xlsx', '.xls'))
    
    def read(self, source, context: TransformContext) -> pd.DataFrame:
        return pd.read_excel(source)
    
    def detect_schema(self, raw_data) -> dict:
        return {"columns": list(raw_data.columns)}
```

### 2. 实现引擎

```python
# engine/file_rule_engine.py
from mother_framework import RuleEngine, TransformContext, FieldValue

class FileRuleEngine(RuleEngine):
    """文件规则引擎"""
    
    def __init__(self, rules_dir: str):
        self.rules_dir = rules_dir
    
    def load_rules(self, context: TransformContext) -> dict:
        # 从文件加载规则
        pass
    
    def get_field_rule(self, field_name: str, context: TransformContext) -> str:
        # 获取字段规则
        pass
    
    def lookup_mapping(self, dict_name: str, key: str, 
                       context: TransformContext) -> FieldValue:
        # 查询字典映射
        pass
    
    def get_target_fields(self, rules: dict) -> list:
        # 获取目标字段列表
        pass
```

### 3. 配置流程

```yaml
# flows/my_flow.yaml
paradigm: "①"
name: "我的流程"
description: "示例流程"

steps:
  - step: 1
    name: "读取输入"
  - step: 2
    name: "加载规则"
  - step: 4
    name: "字段转换"
  - step: 9
    name: "数据校验"
  - step: 10
    name: "输出"
```

### 4. 执行业务

```python
# main.py
from mother_framework import DataTransformer, TransformContext
from adapters.excel_source import ExcelSourceAdapter
from adapters.excel_output import ExcelOutputAdapter
from engine.file_rule_engine import FileRuleEngine
from engine.transform_engine import StandardTransformEngine
from engine.validation_engine import StandardValidator

# 初始化transformer
transformer = DataTransformer(
    source_adapter=ExcelSourceAdapter(),
    rule_engine=FileRuleEngine("./rules"),
    transform_engine=StandardTransformEngine(),
    validator=StandardValidator(),
    output_adapter=ExcelOutputAdapter()
)

# 创建上下文
context = TransformContext(
    business_type="my_business",
    source_system="excel",
    target_system="sap",
    period="2026-04"
)

# 执行转换
result = transformer.transform_with_flow(
    flow_config="./flows/my_flow.yaml",
    input_source="./input/data.xlsx",
    context=context
)

print(f"输出: {result.output_file}")
print(f"校验: {'通过' if result.validation_passed else '失败'}")
```

---

## 约束检查

### 检查流程是否符合范式

```python
from mother_framework import validate_flow_against_paradigm

flow_steps = [
    {"step": 1},
    {"step": 2},
    {"step": 4},
    {"step": 9},
    {"step": 10}
]

errors = validate_flow_against_paradigm(flow_steps, "format_convert")
if errors:
    print(f"违反约束: {errors}")
else:
    print("流程合规")
```

### 检查组合范式

```python
from mother_framework import validate_flow_against_paradigms

errors = validate_flow_against_paradigms(
    flow_steps, 
    ["format_convert", "rule_calculation"]
)
```

---

## 组合范式详解

### 什么是组合范式

组合范式是指一个业务流程同时符合多个范式的约束。例如：
- **费用预提+分摊**：需要先格式转换（范式①），再分摊计算（范式③）
- **银行对账**：需要多源核对（范式②），同时格式转换（范式①）
- **定时计提**：需要规则计算（范式③），同时定时推送（范式⑤）

### 组合范式规则

| 规则 | 说明 |
|------|------|
| **必须步骤** | 所有范式必须步骤的**并集** |
| **禁止步骤** | 只有当**所有范式都禁止**时才禁止 |
| **可重复步骤** | **任一范式允许**即可重复 |
| **步骤支持** | 每个步骤只需被**至少一个范式**支持 |

### 常见组合范式

#### ①+③：格式转换 + 规则计算
**典型场景**：费用预提分摊
```yaml
paradigms:
  - "format_convert"
  - "rule_calculation"

steps:
  - step: 1    # 读取（①+③共同）
  - step: 2    # 加载规则（①+③共同）
  - step: 4    # 字段转换（①必须）
  - step: 4    # 计算（③必须，可重复）
  - step: 6    # 合并分摊（③必须）
  - step: 9    # 校验（①+③共同）
  - step: 10   # 输出（①+③共同）
```

#### ①+②：格式转换 + 多源核对
**典型场景**：银行对账
```yaml
paradigms:
  - "format_convert"
  - "multi_source_check"

steps:
  - step: 1    # 读取源1（②必须）
  - step: 1    # 读取源2（②必须，可重复）
  - step: 4    # 转换+比对（①+②）
  - step: 9    # 校验（①+②共同）
  - step: 10   # 输出差异报告（①+②共同）
```

#### ③+⑤：规则计算 + 定时推送
**典型场景**：月结定时计提
```yaml
paradigms:
  - "rule_calculation"
  - "scheduled_push"

trigger:
  cron: "0 2 1 * *"  # 每月1日凌晨2点

steps:
  - step: 1    # 读取（③+⑤共同）
  - step: 2    # 加载规则（③+⑤共同）
  - step: 4    # 计算（③必须）
  - step: 6    # 分摊（③必须）
  - step: 9    # 校验（③+⑤共同）
  - step: 10   # 推送（⑤必须）
```

### 组合范式配置示例

完整示例见 `flows/` 目录：
- `paradigm_01_03_combined/expense_allocation_with_voucher.yaml` - ①+③组合
- `paradigm_01_02_combined/bank_reconciliation.yaml` - ①+②组合
- `paradigm_03_05_combined/month_end_accrual.yaml` - ③+⑤组合

### 组合范式验证代码

```python
from mother_framework import (
    validate_flow_against_paradigms,
    get_combined_paradigm_info
)

# 获取组合范式信息
info = get_combined_paradigm_info(["format_convert", "rule_calculation"])
print(f"必须步骤: {info['required_steps']}")
print(f"可选步骤: {info['optional_steps']}")
print(f"禁止步骤: {info['forbidden_steps']}")

# 验证流程
flow_steps = [
    {"step": 1}, {"step": 2}, {"step": 4}, 
    {"step": 6}, {"step": 9}, {"step": 10}
]

errors = validate_flow_against_paradigms(
    flow_steps, 
    ["format_convert", "rule_calculation"]
)

if errors:
    print("验证失败:")
    for e in errors:
        print(f"  - {e}")
else:
    print("✓ 组合范式验证通过")
```

---

## 宪法验证

```python
from mother_framework import verify_constitution

is_valid, violations = verify_constitution()
if not is_valid:
    print("框架违反宪法:")
    for v in violations:
        print(f"  - {v}")
```

---

## 合规检查与突破记录

### 基本流程

```python
from mother_framework import (
    ConstitutionChecker,
    require_breakthrough_approval,
    BreakthroughRecorder
)
import yaml

# 加载流程配置
with open("./flows/my_flow.yaml", 'r') as f:
    flow_config = yaml.safe_load(f)

# 检查是否需要突破
checker = ConstitutionChecker()
can_execute, recorder = require_breakthrough_approval(
    checker, flow_config, "my_skill"
)

if not can_execute:
    # 有冲突，保存突破记录等待审批
    recorder.save_to_file("./breakthrough.yaml")
    print("发现冲突，请审批后重新执行")
else:
    # 完全合规，继续执行
    print("合规检查通过")
```

### 突破记录文件格式

```yaml
# breakthrough.yaml
skill_name: "my_skill"
constitution_version: "1.0.0"
generated_at: "2026-04-09 10:00:00"

constitution_violations:
  - article: "第三条"
    clause: "范式约束"
    violation: "范式③规则计算缺少必须步骤6"
    justification: "当前业务场景不需要合并"
    approved_by: "财务经理"
    approved_at: "2026-04-09 10:30:00"
    status: "approved"
```

### 完整示例

```python
from mother_framework import (
    DataTransformer,
    TransformContext,
    ConstitutionChecker,
    require_breakthrough_approval,
    BreakthroughRecorder
)

# 1. 加载配置
flow_config = load_flow_config("./flows/my_flow.yaml")

# 2. 合规检查
checker = ConstitutionChecker()
can_execute, recorder = require_breakthrough_approval(
    checker, flow_config, "my_skill"
)

# 3. 处理突破
if not can_execute:
    if os.path.exists("./breakthrough.yaml"):
        recorder = BreakthroughRecorder.load_from_file("./breakthrough.yaml")
        if recorder.has_pending_violations():
            print("存在未审批的突破")
            return
    else:
        recorder.save_to_file("./breakthrough.yaml")
        print("突破记录已保存，请审批")
        return

# 4. 继续执行
result = transformer.transform_with_flow(...)
```

---

## 文件清单

| 文件 | 类型 | 说明 |
|------|------|------|
| `CONSTITUTION.md` | 宪法 | 必须遵守的约束条款（7条） |
| `README.md` | 文档 | 使用说明 |
| `src/__init__.py` | 代码 | 框架入口 |
| `src/core/interfaces.py` | 代码 | 抽象接口定义 |
| `src/core/transformer.py` | 代码 | 10步流程骨架 |
| `src/core/flow_orchestrator.py` | 代码 | 流程编排器（支持组合范式） |
| `src/core/paradigm_framework.py` | 代码 | 6大范式约束（支持组合验证） |
| `src/core/compliance.py` | 代码 | 合规检查与突破记录 |
| `flows/` | 示例 | 流程配置示例（含组合范式） |

---

## 版本历史

- **v1.0.0** (2026-04-09): 母框架初版
  - 7条宪法条款
  - 6大范式约束
  - 10步流程骨架
  - 合规检查与突破记录机制
  - **组合范式支持**：流程可同时声明多个范式

---

**注意**: 任何基于本框架的实现，必须首先阅读并理解 `CONSTITUTION.md`
